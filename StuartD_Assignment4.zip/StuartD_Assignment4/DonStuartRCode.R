#Read data file in from working directory and put in a dataframe
train <- data.frame(read.csv("train.csv", header=TRUE, sep=","))

#examine the dataframe
str(train)

#load ggplot2
library(ggplot2)

#create heatmap
heatmap <- ggplot(train, aes(x = Fare, y = Age)) + geom_line(aes(group = as.factor(Survived), color = as.factor(Survived))) + xlab('Fare') + ylab('Age') + ggtitle('Survivors by Age and Ticket Fare') + scale_fill_discrete(name="Survived")

#create violinplot
violin_p <- gglot(train, aes(x=factor(Pclass), y = Age)) + geom_violin(aes(fill = as.factor(Survived)))
#add titles to violin_p
violin_p + ggtitle("Age and Class by Survival") + xlab("Class") + scale_fill_discrete(name="Survived")

#create facetplot
Facet_plot <- ggplot(train, aes(Fare, Age)) + geom_point()
#turn into facet grid
Facet_plot + facet_grid(. ~ Pclass)

#create histogram
histogram <- ggplot(train, aes(Age)) + geom_histogram()
#add fill to histogram
histogram + geom_histogram(aes(fill = as.factor(Survived))) + scale_alpha_discrete(name="Survived")

#create whiskerplot
whisker_plot <- ggplot(train, aes(factor(Pclass), Age)) + geom_boxplot(aes(fill =as.factor(Survived)))
#add titles to whisker plot
whisker_plot + ggtitle("Survival Based on Class and Age") + xlab("Passenger Class") + scale_fill_discrete(name="Survived")

#view plots
Facet_plot
heatmap
histogram
violin_p
whisker_plot



