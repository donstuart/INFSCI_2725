import sys
import pymongo
from pymongo import MongoClient

client = MongoClient()
db = client['moviesdb']



for line in sys.stdin:
    line = line.strip()
    userID, movieID, rating, timeStamp = line.split('::')
    db.Ratings.insert({"UserID":userID,"MovieID":movieID,"Rating": float(rating)})

print("Ratings have been added to MongoDB!")    

